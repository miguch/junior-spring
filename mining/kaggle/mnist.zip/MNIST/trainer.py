import loader
import torch
import argparse
import torch.utils.data as utils
import torch.nn.functional as F
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from PIL import Image
import numpy as np
import pandas

def output_to_csv(li):
    items = [[ind+1, li[ind]] for ind in range(len(li))]
    pandas.DataFrame(items).to_csv('./output.csv', header=['ImageId', 'Label'], index=False)



class Net(torch.nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 20, (5,5), 1)
        self.conv2 = nn.Conv2d(20, 50, (5,5), 1)
        self.fc1 = nn.Linear(4*4*50, 500)
        self.fc2 = nn.Linear(500, 10)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(x, 2, 2)
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, 2, 2)
        x = x.view(-1, 4*4*50)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return F.log_softmax(x, dim=1)

def train(args, model, device, train_loader, optimizer, epoch):
    model.train()
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device).float(), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = F.nll_loss(output, target)
        loss.backward()
        optimizer.step()
        if batch_idx % args.log_interval == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                100. * batch_idx / len(train_loader), loss.item()))

def test(args, model, device, test_loader):
    model.eval()
    test_loss = 0
    correct = 0
    result = []
    with torch.no_grad():
        for [data] in test_loader:
            data = data.to(device).float()
            output = model(data)
            pred = output.argmax(dim=1, keepdim=True).item() # get the index of the max log-probability
            result.append(pred)

    output_to_csv(result)
    print('\nTest Done')


def main():
    parser = argparse.ArgumentParser(description='PyTorch MNIST Example')
    parser.add_argument('--batch-size', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--test-batch-size', type=int, default=1000, metavar='N',
                        help='input batch size for testing (default: 1000)')
    parser.add_argument('--epochs', type=int, default=50, metavar='N',
                        help='number of epochs to train (default: 10)')
    parser.add_argument('--lr', type=float, default=0.001, metavar='LR',
                        help='learning rate (default: 0.01)')
    parser.add_argument('--momentum', type=float, default=0.5, metavar='M',
                        help='SGD momentum (default: 0.5)')
    parser.add_argument('--log-interval', type=int, default=10, metavar='N',
                        help='how many batches to wait before logging training status')
    parser.add_argument('--test', dest='test', action='store_true')
    parser.set_defaults(test=False)
    
    parser.add_argument('--save-model', action='store_true', default=True, help='For Saving the current Model')
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    kwargs = {'num_workers': 1, 'pin_memory': True} if torch.cuda.is_available() else {}

    train_data_np, train_label_np = loader.load_train_set()
    train_data = torch.from_numpy(train_data_np / 255)
    train_data = train_data.reshape(len(train_data), 1, 28, 28)
    train_label = torch.from_numpy(train_label_np)
    test_data = torch.from_numpy(loader.load_test_set() / 255)
    test_data = test_data.reshape(len(test_data), 1, 28, 28)

    train_set = utils.TensorDataset(train_data, train_label)
    train_loader = utils.DataLoader(train_set, args.batch_size, True)
    test_set = utils.TensorDataset(test_data)
    test_loader = utils.DataLoader(test_set)
    model = Net().to(device)
    if not args.test:
        optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum)
        for epoch in range(1, args.epochs + 1):
            train(args, model, device, train_loader, optimizer, epoch)

        if (args.save_model):
            torch.save(model.state_dict(),"mnist_cnn.pt")
    else:
        model.load_state_dict(torch.load("mnist_cnn.pt", map_location='cuda' if torch.cuda.is_available() else 'cpu'))
        test(args, model, device, test_loader)

if __name__ == '__main__':
    main()
