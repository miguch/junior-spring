import pandas
import os

data_dir = 'data'
test_name = 'test.csv'
train_name = 'train.csv'

test_path = os.path.join(data_dir, test_name)
train_path = os.path.join(data_dir, train_name)

def load_train_set():
    data = pandas.read_csv(train_path)
    mat = data.values
    return mat[:, 1:], mat[:, 0]

def load_test_set():
    data = pandas.read_csv(test_path)
    return data.values




